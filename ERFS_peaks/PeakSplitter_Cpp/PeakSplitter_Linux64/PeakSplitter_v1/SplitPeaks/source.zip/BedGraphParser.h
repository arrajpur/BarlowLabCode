#pragma once
#include "Shared.h"
#include "Parser.h"
#include "wigPosition.h"

class BedGraphParser :
	public Parser
{
public:
	BedGraphParser::BedGraphParser(ifstream* bufReader, int position);
	~BedGraphParser(void);
	wigPosition* BedGraphParser::nextPosition();
};
